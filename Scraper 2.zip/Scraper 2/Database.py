import sqlite3

class ScraperDB():
    def __init__(self):
        self.connection = sqlite3.connect('scraper-db.db')
    def insertNew(self, contains):
        try:
            self.connection.execute(
            '''INSERT INTO news (title, link, description, body) VALUES (:n_title, :n_link, :n_desc, :n_body)''',
                {"n_title" : contains[0], "n_link" : str(contains[1]), "n_desc": str(contains[2]), "n_body" : str(contains[3])})
            self.connection.commit()
            return "Done"
        except:
            return "This new is stored before"


def getNew(url):
    with sqlite3.connect('scraper-db.db') as connection:
        cursor = connection.execute(
            '''SELECT title, link, description, body FROM news WHERE link = :url_f''',
            {"url_f": url})
        row = cursor.fetchone()
        if (row != None):
            return row
        else:
            return -1


def getNews():
    with sqlite3.connect('scraper-db.db') as connection:
        cursor = connection.execute(
            '''SELECT id, title, link, description, body FROM news''')
        rows = cursor.fetchall()
        if(rows != None):
            return rows
        else:
            return -1

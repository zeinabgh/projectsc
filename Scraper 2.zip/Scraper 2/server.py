from flask import Flask, url_for, request, redirect, render_template, jsonify
import Database

app = Flask(__name__)
#myDb = Database.ScraperDB()

@app.route("/")
def mainPage():
    res = []
    myNews = Database.getNews()
    for myNew in myNews:
        tmp = myNew[3][0:450] + " ..."
        #myNew.append(tmp)
        res.append([myNew[0], myNew[1], myNew[2], myNew[3], myNew[4], tmp])
    #print (myNews)
    return(render_template("results.html", results = res))

@app.route("/search")
def searchPage():
    return (render_template("main.html"))

@app.route("/_get_News")
def getNew():
    #myUrl = request.form["myForm"]
    myUrl = request.args.get('value2', 0, type=str)
    print (type(myUrl))
    result = Database.getNew(str(myUrl))
    print (result)
    return jsonify(result = result)


if __name__ == "__main__":
    app.debug = True
    app.run()

